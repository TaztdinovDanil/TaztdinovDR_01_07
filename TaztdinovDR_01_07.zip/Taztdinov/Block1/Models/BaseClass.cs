﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Block1.Models
{
    public class BaseClass
    {
        public string type { get; set; }/*Описание конструктора*/

        public double number { get; set; }

        public double diameter { get; set; }

        public BaseClass (string Type, double Number,double Diameter)
        {
            this.type = Type;
            this.number = Number;
            this.diameter = Diameter;
        }

        public virtual double Q(double diameter, double number)
        {
            var Q = diameter / number;
            return Q;
        }

        public void PrintInfo()
        {
            Console.WriteLine($"Q = {Q(diameter, number)}");
        }
    }
}
