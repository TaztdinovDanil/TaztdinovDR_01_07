﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Block1.Models
{
    public class ChildClass :BaseClass
    {
        public bool p { get; set; }/*Описание конструктора*/
        public ChildClass (string Type, double Number, double Diameter, bool P) : base(Type, Number, Diameter)
        {
            this.p = P;
        }

        public virtual double QP(double diameter, double number, bool p)
        {
            var Qp = 0.0;
            if(p == true)
            {
                Qp = 2 * Q(diameter, number);
            }
            else if (p == false)
            {
                Qp = 0.7 * Q(diameter, number);
            }
            return Qp;
        }

        public void PrintChildInfo ()
        {
            Console.WriteLine($"Qp = {QP(diameter, number, p)}");
        }
    }
}
