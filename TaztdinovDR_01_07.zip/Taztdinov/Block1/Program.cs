﻿using Block1.Models;

BaseClass class1 = new BaseClass("Danil", 3, 21);// Базовый класс
ChildClass class2 = new ChildClass("Danil", 3, 21, false);// Класс потомок
class1.PrintInfo();//Вывод Q
class2.PrintChildInfo();//Вывод Qp
