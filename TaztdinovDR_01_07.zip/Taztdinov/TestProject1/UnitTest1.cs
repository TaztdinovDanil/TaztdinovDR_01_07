using Microsoft.VisualStudio.TestTools.UnitTesting;
using Block1.Models;
using Assert = Microsoft.VisualStudio.TestTools.UnitTesting.Assert;

namespace TestProject1
{
    [TestClass]
    public class Tests
    {
        [TestMethod]
         public void Base�lass�heck()// testing the base class
         {
            string type = "������ ������";
            double number = 3;
            double diameter = 5;
            BaseClass baseclass = new BaseClass(type, number, diameter);
            Assert.AreEqual(type,baseclass.type);
            Assert.AreEqual(number, baseclass.number);
            Assert.AreEqual(diameter, baseclass.diameter);
         }
        [TestMethod]
        public void ChildClassCheck() // testing the child class
        {
            string type = "������ ��������";
            double number = 2;
            double diameter = 12;
            bool p = true;
            ChildClass childclass = new ChildClass(type, number, diameter, p);
            Assert.AreEqual(type, childclass.type);
            Assert.AreEqual(number, childclass.number);
            Assert.AreEqual(diameter, childclass.diameter);
            Assert.AreEqual(p, childclass.p);
        }
        [TestMethod]
        public void CheckQ()//testing the q
        {
            string type = "������ �����������";
            double number = 7;
            double diameter = 11;
            BaseClass baseclass = new BaseClass(type, number, diameter);
            double Q = baseclass.Q(diameter, number);
            Assert.AreEqual(Q, baseclass.Q(diameter, number));
        }
        [TestMethod]
        public void CheckQp()// testing the Qp
        {
            string type = "������ �������";
            double number = 2;
            double diameter = 12;
            bool p = false;
            ChildClass childclass = new ChildClass(type, number, diameter, p);
            double QP = childclass.QP(diameter, number, p);
            Assert.AreEqual(QP, childclass.QP(diameter, number, p));
        }


    }
}